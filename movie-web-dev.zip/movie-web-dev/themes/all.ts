import teal from "./list/teal";
import blue from "./list/blue";
import red from "./list/red";
import gray from "./list/gray";

export const allThemes = [
  teal,
  blue,
  gray,
  red
]
